import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Minisom library and module is used for performing Self Organizing Maps
from minisom import MiniSom
# to suppress warnings
from warnings import filterwarnings
filterwarnings('ignore')
# Loading Data
data = pd.read_csv('Credit_Card_Applications.csv')
# X 
data
data.shape
data.info()
X = data.iloc[:, 1:14].values
y = data.iloc[:, -1].values
pd.DataFrame(X)
pd.DataFrame(y)
