import numpy as p
#from peach import *
from random import shuffle
def show(x):
    n=len(x)
    for i in range(0,n):
        if i%5==0:
            print
        if x[i]==1:
            print ('*')
        else:
            print (' ')
        training_set=[
            array([-1,-1,-1,-1,-1,
                   -1,1,-1,1,-1,
                   1,-1,-1,-1,1,
                   1,-1,-1,-1,1,         #A
                   1,1,1,1,1,
                   1,-1,-1,-1,1,
                   1,-1,-1,-1,1]),
            array([1,1,1,1,1,
                   1,-1,-1,-1,-1,
                   1,-1,-1,-1,-1,
                   1,1,1,1,-1,           #E
                   1,-1,-1,-1,-1,
                   1,-1,-1,-1,-1,
                   1,1,1,1,1]),
            array([-1,1,1,1,-1,
                   -1,-1,1,-1,-1,
                   -1,-1,1,-1,-1,
                   -1,-1,1,-1,-1,        #O
                   -1,-1,1,-1,-1,
                   -1,-1,1,-1,-1,
                   -1,1,1,1,-1]),
            array([-1,-1,1,-1,-1,
                   -1,1,-1,1,-1,
                   1,-1,-1,-1,1,
                   1,-1,-1,-1,1,
                   1,-1,-1,-1,1,         #I
                   -1,1,-1,1,-1,
                   -1,1,1,1,-1]),
            array([1,-1,-1,-1,1,
                   1,-1,-1,-1,1,
                   1,-1,-1,-1,1,
                   1,-1,-1,-1,1,         #U
                   1,-1,-1,-1,1,
                   1,-1,-1,-1,1,
                   -1,1,1,1,-1])]
        x=array(training_set[0])
        n=len(x)
        noise_position=range(n)
        shuffle(noise_position)
        for k in noise_position[:8]:
            x[k]=-x[k]
            x=x.reshape((n,1))
            nn=Hopfield(n)
            nn.train(training_set)
            i=0
            xx=array(x)
        while i <100:
            xx=nn.step(xx)
            show(xx)
            i=i+1
        print ("\n\n"+"-"*40)
        print ("\n\nInitial state:")
        show(x)
        print ("\n\nFinal state:")
        show(xx)

            
