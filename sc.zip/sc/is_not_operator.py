x=5.2
if(type(x) is not int):
    print("true")
else:
    print("false")
